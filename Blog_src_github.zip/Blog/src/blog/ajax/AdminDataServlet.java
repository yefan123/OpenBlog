package blog.ajax;

import java.io.IOException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import blog.service.AdminService;
import blog.service.TagService;

@WebServlet("/AdminDataServlet")
public class AdminDataServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//获取操作码
		String op = request.getParameter("op");
		//初始化服务对象
		AdminService as = AdminService.getInstance();

		switch (op) {
		
		case "edit_article":
		
			String a_id1 = request.getParameter("article_id");
			request.setAttribute("edit_article", as.getArticle(a_id1));		
				
			//获取标签
			ServletContext application = this.getServletContext();
			TagService ts= TagService.getInstance();
			application.setAttribute("all_tags_ranked", ts.getRankedTags(100));

			request.getRequestDispatcher("/admin/edit.jsp").forward(request, response);
			break;
			
			
		case "delete_article":
			String a_id2 = request.getParameter("article_id");
			as.delteArticle(a_id2);
			break;
		
		case "tag_delete":
			String tagId=request.getParameter("tagId");
			as.dropATag(Integer.parseInt(tagId));
			break;
		
		case "add_tag":
			String tagName=request.getParameter("tagName").trim();
			as.addATag(tagName);
			break;
		
		default:
			break;

		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
