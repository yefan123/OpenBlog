package blog.servlet;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import blog.service.ArticleService;
import blog.service.TagService;

@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		if (request.getSession().getAttribute("user")!=null) {
			
			// 获取application对象
			ServletContext application = this.getServletContext();
		
		
			//传所有文章(不含content)
			ArticleService as =  ArticleService.getInstance();		
			request.setAttribute("articles",as.getArticlesWithoutContent(0, 100));
		
			TagService ts = TagService.getInstance();
			// 所有标签(排名后)
			application.setAttribute("all_tags_ranked", ts.getRankedTags(100));
		
			//传网站的统计数据  	//放到LoginServlet的init()中了
			//request.setAttribute("visited", VisitorDB.totalVisit());
		
			//转发
			request.getRequestDispatcher("/admin/admin.jsp").forward(request, response);
		
		}else {
			//权限不够
			response.sendError(403);
		}
		
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
