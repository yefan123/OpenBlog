package blog.service;

import java.util.List;

import blog.dao.HistoryDao;
import blog.daoImpl.HistoryDaoImpl;

public class HistoryService {

	
	private HistoryDao dao;

	private static HistoryService instance;
	private HistoryService(){	
		dao =  HistoryDaoImpl.getInstance();
	}
	
	public static final HistoryService getInstance(){
		if (instance == null) {
			try {
				instance = new HistoryService();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return instance;
	}
	
	
	
	public List getHistoryList(int number) {
		return dao.getHistoryList(number);
	}

	public int getVersionsCount() {
		// TODO Auto-generated method stub
		return dao.howManyVersions();
	}
	
	
	
}
