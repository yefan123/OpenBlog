
/* 
* 获取ajax处理对象		
 * @returns {xmlhttp}
 */

function getXHR(){	
	var xmlhttp;
	if (window.XMLHttpRequest) {
		xmlhttp = new XMLHttpRequest();
	} else {
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	return xmlhttp;	
}
/*
 *发送给服务器
 */
function sendURL(url){	
	// 获取ajax
	var xmlhttp = getXHR();		
	xmlhttp.onreadystatechange = function() {
//		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
//			//这里可以写 服务器返回解结果后的处理
//		}
	}
	xmlhttp.open("POST", url, true);
	xmlhttp.send();		
}
/**
 * 在某个分类中找到指定的一个input
 * @param class_name
 * @param name
 * @returns
 */
function findInputInClass(class_name , name){
	//获取class_name类的 input 所有输入框数组
	var inputs = document.getElementsByClassName(class_name);
	var input;		
	//找到值等于 name 的输入框
	for(var i=0 ;i<inputs.length;i++){		
		if(inputs[i].value == name){
			input = inputs[i];
			break;
		}			
	}
	return input;	
}

///**
// * 编辑文章
// * @param article_id
// */
//function edit_article(article_id){
//	//send
//	var url = "/Blog/AdminDataServlet?op=edit_article"+"&&article_id="+article_id;
//	sendURL(url);
//}

/**
 * 删除文章
 * @param article_id
 */
function delete_article(hod , article_id){
	
	
	
	var url = "/Blog/AdminDataServlet?op=delete_article"+"&&article_id="+article_id;
	
	// 获取ajax
	var xmlhttp = getXHR();		
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			//remove 视图
			var recorder = hod.parentNode.parentNode.parentNode;	
			var recorder_parent = recorder.parentNode;
			recorder_parent.removeChild(recorder);
		}
	}
	xmlhttp.open("POST", url, true);
	xmlhttp.send();		
	
	
	
}




/**
 * 删除tag
 * @param hod
 * @param id
 */
function delet_tag(hod,id){
	
	//后台删除
	var url = "/Blog/AdminDataServlet?op=tag_delete&&tagId="+id;
	// 获取ajax
	var xmlhttp = getXHR();		
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			//remove 视图
			var recorder = hod.parentNode.parentNode.parentNode;
			var recorder_parent = recorder.parentNode;
			recorder_parent.removeChild(recorder);
		}
	}
	xmlhttp.open("POST", url, true);
	xmlhttp.send();		

	
	
	
}




/**
 * 添加tag
 * @param hod
 */
function add_tag(hod){
	
	//获得新tag的名字
	let tagName=document.querySelector('#newTag').value.trim();
	
	if(tagName==''){
		alert("标签名不能为空!");
	}else{
		
	
	//后台删除
	var url = "/Blog/AdminDataServlet?op=add_tag&&tagName="+tagName;
	// 获取ajax
	var xmlhttp = getXHR();		
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			//刷新页面
			location.reload();
		}
	}
	xmlhttp.open("POST", url, true);
	xmlhttp.send();		

	
	}
	
	
}

