window.onresize=function(){
	let list=document.querySelectorAll('.label_container');
	if(document.querySelector('#right_content').clientWidth<660){
		for(let i of list){
			i.style.width='25%';
		}
	}else{
		for(let i of list){
			i.style.width='20%';
		}
	}
}